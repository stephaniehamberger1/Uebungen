Das Klicken auf den Slider funktioniert nur teilweise. 
Hei�t man klickt auf den Slider und der Thump sollte sich zum geklickten Punkt bewegen. Bei meinem Silder bewegt sich der
Thump erst, wenn man den Mauszeiger bewegt hat.